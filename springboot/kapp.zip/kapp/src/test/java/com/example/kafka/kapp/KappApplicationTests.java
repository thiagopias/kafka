package com.example.kafka.kapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KappApplicationTests {

	@Test
	void contextLoads() {
	}

}
