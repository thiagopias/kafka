package com.example.kafka.kapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KappApplication {

	public static void main(String[] args) {
		SpringApplication.run(KappApplication.class, args);
	}

}
